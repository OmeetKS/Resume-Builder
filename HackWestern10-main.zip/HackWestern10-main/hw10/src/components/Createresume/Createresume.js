import React from "react";

export const Home = () => {
  return <h1>CreateResume</h1>;
};